import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class InvaderDefender here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class InvaderDefender extends Actor
{
    /**
     * Act - do whatever the InvaderDefender wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        checkKeyPressLR();
        fire();
    }

    /**
     * Check whether a keyboard key has been pressed and react if it has.
     */
    private void checkKeyPressLR()
    {
        if (Greenfoot.isKeyDown("right"))
        {
            setLocation(getX()+4, getY());
        }

        if (Greenfoot.isKeyDown("left"))
        {
            setLocation(getX()-4, getY());
        }
    }

    /**
     * Check whether a keyboard key has been pressed and react if it has.
     */
     private void fire()
     {
        if (Greenfoot.isKeyDown("f"))
        {
            int x = getX();
            int y = getY();
            getWorld().addObject(new Lazer(),x, y);
        }
     }
}
