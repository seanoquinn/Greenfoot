import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class OuterSpace here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class OuterSpace extends World
{

    /**
     * Constructor for objects of class OuterSpace.
     * 
     */
    public OuterSpace()
    {    
        super(900, 700, 1); 
        prepare();
        setPaintOrder(InvaderDefender.class,Lazer.class);
    }

    public void act()
    {
       if (Greenfoot.getRandomNumber(250) < 1)
       {
        addObject(new Invader(), Greenfoot.getRandomNumber(870), 10);
       } 
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {        
        InvaderDefender defender = new InvaderDefender();
        addObject(defender,450,640);
    }
}
