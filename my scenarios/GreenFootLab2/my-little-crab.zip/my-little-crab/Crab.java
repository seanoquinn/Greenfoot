import greenfoot.*;

/**
 * This class defines a crab. Crabs live on the beach.
 */
public class Crab extends Actor
{
    public void act()
    {
        checkKeyPress();
        //turnLeft();
        //turnRight();
        //turnAtEdge();
        //randomTurn();
        move(5);
        lookForWorm();
        //anyWormsLeft();
    }

public void checkKeyPress()
{
    if (Greenfoot.isKeyDown("left"))
    {
        turn(-4);
    }
    if (Greenfoot.isKeyDown("right"))
    {
        turn(4);
    }
}

public void turnLeft()
{
    if (Greenfoot.isKeyDown("left"))
    {
        turn(-4);
    }
}

public void turnRight()
{
    if (Greenfoot.isKeyDown("right"))
    {
        turn(4);
    }
}

/**
 * Check whether we have found a work.
 * If we have, eat it. If not, do nothing.
 */   
    public void lookForWorm()
    {
        if ( isTouching(Worm.class))
        {
            removeTouching(Worm.class);
            Greenfoot.playSound("slurp.wav");
        }  
    }

/**
 * Check for the existence of worms.
 * If they are gone, stop.
 */   
   // public void anyWormsLeft()
   // {
   //     if (Greenfoot.getObjects(Worm.class) == false)
   //     {
   //         Greenfoot.stop();
   //     }  
   // }

/**
 * Genrate a random movement.
 * Get a random number between 0-99 and if less than 10,
 * Then rotate the object 45 degrees in either direction.
 */   
    public void randomTurn()
    {
        if ( Greenfoot.getRandomNumber(100) < 10 )
        {
            turn(Greenfoot.getRandomNumber(90)-45);
        } 
    }

/**
 * Check for contact with the game edge.
 * If the object is at the edge,
 * Then turn the object a random number between 0-99.
 */  
    public void turnAtEdge()
    {
        if ( isAtEdge() )
        {
            turn(Greenfoot.getRandomNumber(100));
        }
    }
}