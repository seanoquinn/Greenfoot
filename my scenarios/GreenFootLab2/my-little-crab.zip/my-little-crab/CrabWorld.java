import greenfoot.*;  // (Actor, World, Greenfoot, GreenfootImage)

public class CrabWorld extends World
{
    /**
     * Create the crab world (the beach). Our world has a size 
     * of 560x560 cells, where every cell is just 1 pixel.
     */
    int crabX;
    int crabY;
    int lobX;
    int lobY;
    int worm1X= Greenfoot.getRandomNumber(375);
    int worm1Y= Greenfoot.getRandomNumber(375);
    int worm2X= Greenfoot.getRandomNumber(375);
    int worm2Y= Greenfoot.getRandomNumber(375);
    int worm3X= Greenfoot.getRandomNumber(375);
    int worm3Y= Greenfoot.getRandomNumber(375);
    int worm4X= Greenfoot.getRandomNumber(375);
    int worm4Y= Greenfoot.getRandomNumber(375);
    public CrabWorld() 
    {
        super(560, 560, 1);
        addObject(new Crab(),100,250);
        addObject(new Worm(),worm1X,worm1Y);
        addObject(new Worm(),worm2X,worm2Y);
        addObject(new Worm(),worm3X,worm3Y);
        addObject(new Worm(),worm4X,worm4Y);
        addObject(new Lobster(),361,100);
    }

    //public static int getPlotValue (int x)
    //{
    //    return 
    //}
}