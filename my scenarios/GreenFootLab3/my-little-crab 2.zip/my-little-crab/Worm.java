import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * This is a worm.
 */
public class Worm extends Actor
{

    // private GreenfootImage image1;
    // private int addWorm;

    // public Worm()
    // {
        // image1 = new GreenfootImage("worm.png");
        // setImage(image1);
        // addWorm = 0;
    // }

    // public void act()
    // {
        // addWorm();
    // }
    
    // public void addWorm()
    // {
       // if ( isTouching(Crab.class))
       // {
            // //addWorm = addWorm + 1;
            // Greenfoot.addObject(worm,Greenfoot.getRandomNumber(425), Greenfoot.getRandomNumber(425));
       // } 
    // }
}
